// 实现：序列化（转化为字节列表/数组），反序列化，求哈希等功能

use bincode;
use serde::{Deserialize, Serialize};

use crypto::digest::Digest;
use crypto::sha3::Sha3;

// 序列化函数用到了 bincode
// https://docs.rs/bincode/1.3.3/bincode/fn.serialize.html
/*
pub fn serialize<T: ?Sized>(value: &T) -> Result<Vec<u8>>
where
    T: Serialize,
 */
// T: ?Sized 表示传入的类型的大小不确定，可以传递动态大小类型的泛型。并且对泛型类型进行约束
pub fn my_serialize<T: ?Sized>(value: &T) -> Vec<u8>
where
    T: Serialize,
{
    let serialized = bincode::serialize(value).unwrap(); // 这里不想返回 Result 类型，所以需要调用 unwrap 函数

    serialized
}

// 反序列化函数
// 写法参考文档：https://docs.rs/bincode/1.3.3/bincode/fn.deserialize.html
/*
pub fn deserialize<'a, T>(bytes: &'a [u8]) -> Result<T>
where
    T: Deserialize<'a>,
 */
// 传入的是一个引用，需要生命周期注解
pub fn my_deserialize<'a, T>(bytes: &'a [u8]) -> T
where
    T: Deserialize<'a>,
{
    let deserialized = bincode::deserialize(bytes).unwrap();

    deserialized
}

// 求哈希的函数
// 传入的是序列化后的字节数组
pub fn get_hash(value: &[u8]) -> String {
    let mut hasher = Sha3::sha3_256();
    hasher.input(value);

    hasher.result_str()
}

/* ----------------- 以下是测试 ----------------- */

// 自定义一个结构体，用来测试序列化和反序列化
#[derive(Serialize, Deserialize, PartialEq, Eq, Debug)] // 添加特性
struct Point {
    x: i32,
    y: i32,
}

#[cfg(test)]
mod tests {
    use crate::coder::Point;
    use crate::coder::{my_deserialize, my_serialize};

    #[test]
    fn coder_works() {
        let point = Point { x: 1, y: 2 };
        let se = my_serialize(&point); // 先进行序列化
        let de: Point = my_deserialize(&se); // 再进行反序列化复原

        assert_eq!(de, point); // 复原后的值与原值相等即表示功能正常
    }
}
