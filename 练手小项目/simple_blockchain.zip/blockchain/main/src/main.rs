use std::thread;
use std::time::Duration;

use core::blockchain;

fn main() {
    let mut bc = blockchain::BlockChain::new_blockchain(); // 创建一条链

    println!("start mining...");
    thread::sleep(Duration::from_secs(5)); // 让线程睡眠一会儿，模拟在挖矿的耗时
    bc.add_block("a -> b: 5BTC.".to_string()); // 添加交易来模拟，每个区块就添加一个交易
    println!("produce a block!");

    println!();

    println!("start mining...");
    thread::sleep(Duration::from_secs(3));
    bc.add_block(String::from("c -> d: 1BTC.")); // 两种传字符串的方式
    println!("produce a block!");

    // 打印一下创始区块，看看效果
    for b in bc.blocks {
        println!("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        println!("{:#?}", b);
        println!();
    }
}
