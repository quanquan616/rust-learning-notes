// 实现区块链

use crate::block; // 需要使用到 block 中的属性、方法

pub struct BlockChain {
    pub blocks: Vec<block::Block>,
}

impl BlockChain {
    // 创建创始区块，不让外部调用，由创建一条链的时候自动调用本方法
    fn new_genesis_block() -> block::Block {
        block::Block::new_block("This is genesis block.".to_string(), String::from("None"))
    }

    // 创建一条链
    pub fn new_blockchain() -> BlockChain {
        BlockChain {
            blocks: vec![BlockChain::new_genesis_block()], // 最开始肯定没有任何区块，直接调用创建创始区块的函数
        }
    }

    // 添加新的区块
    pub fn add_block(&mut self, data: String) {
        let pre_block = &self.blocks[&self.blocks.len() - 1]; // 得到最后一个区块，新的区块链在它的后面

        // pre_block.hash 属性，属于上一行代码中的 pre_block
        // 解决所有权转移的方式：clone 一份过去。或者实现 Copy 特性。
        let new_block = block::Block::new_block(data, pre_block.hash.clone());

        self.blocks.push(new_block);
    }
}
