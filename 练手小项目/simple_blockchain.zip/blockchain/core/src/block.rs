use serde::{Deserialize, Serialize};

use chrono::prelude::*;
use utils::coder; // 自定义的 utils 包

// 定义区块头
#[derive(Serialize, Deserialize, PartialEq, Eq, Debug)] // 添加序列化、反序列化特性，因为 coder::my_serialize(T) 函数中的泛型限制必须实现 Serialize
pub struct BlockHeader {
    pub time: i64,        // 时间
    pub tx_hash: String,  // 交易的 merkle 哈希
    pub pre_hash: String, // 前一个区块的哈希
}

// 定义区块
#[derive(Debug)]
pub struct Block {
    pub header: BlockHeader, // 区块头
    pub hash: String,        // 自身的哈希
    pub data: String,        // 交易数据。只放一个来模拟
}

/* 实现区块的一些方法 */
impl Block {
    pub fn set_hash(&mut self) {
        // self.header.time = Utc::now().timestamp(); // 求时间戳
        let header = coder::my_serialize(&self.header);
        self.hash = coder::get_hash(&header);
    }

    // 创建区块
    pub fn new_block(data: String, pre_hash: String) -> Block {
        let transaction = coder::my_serialize(&data);
        let tx_hash = coder::get_hash(&transaction);

        // create
        let mut block = Block {
            header: BlockHeader {
                time: Utc::now().timestamp(),
                tx_hash,
                pre_hash,
            },
            hash: "".to_string(),
            data,
        };

        block.set_hash();

        block
    }
}
