pub fn goodbye() -> String {
    "再见。".to_string()
}
