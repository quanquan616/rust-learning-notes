// 模块的代码

pub mod farewells;
pub mod greetings;
