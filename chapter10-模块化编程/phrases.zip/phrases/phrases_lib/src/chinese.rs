// 模块的代码

mod farewells;
mod greetings;

// 将函数重导出到 phrases_lib::chinese 路径下
pub use self::farewells::goodbye;
pub use self::greetings::hello;
