use phrases_lib::chinese; // 重导出后，只需要导入 chinese 即可使用其下两个模块中的函数。无需再显式导入完整路径
use phrases_lib::english::{farewells, greetings};

fn main() {
    println!("Hello in Chinese: {}", chinese::hello());
    println!("Goodbye in Chinese: {}", chinese::goodbye());

    println!("Hello in English: {}", greetings::hello());
    println!("Goodbye in English: {}", farewells::goodbye());
}
