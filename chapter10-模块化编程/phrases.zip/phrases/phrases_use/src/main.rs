use phrases_lib::chinese; // 重导出后，无需再引入子模块名称
use phrases_lib::english::{farewells, greetings};

fn main() {
    println!("Hello in Chinese: {}", chinese::hello());
    println!("Goodbye in Chinese: {}", chinese::goodbye());

    println!("Hello in English: {}", greetings::hello());
    println!("Goodbye in English: {}", farewells::goodbye());
}
